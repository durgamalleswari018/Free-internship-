
"use strict";

const $ = id => document.getElementById(id);
const STORAGE_KEY = "collegeProDB";
const THEME_KEY = "collegeProTheme";
const LOGIN_KEY = "collegeProLoggedIn";

const initialData = {
  students: [
    { id: 1, name: "Ananya Rao", email: "ananya@example.com", phone: "9876543210", department: "CSE", course: "B.Tech", year: "2nd Year" },
    { id: 2, name: "Rahul Kumar", email: "rahul@example.com", phone: "9876501234", department: "ECE", course: "B.Tech", year: "3rd Year" },
    { id: 3, name: "Priya Sharma", email: "priya@example.com", phone: "9876512345", department: "CSE", course: "B.Tech", year: "1st Year" }
  ],
  faculty: [
    { id: 1, name: "Dr. S. Kumar", email: "kumar@college.edu", phone: "9876543211", department: "CSE", subject: "Programming" },
    { id: 2, name: "Prof. R. Devi", email: "devi@college.edu", phone: "9876543212", department: "ECE", subject: "Electronics" }
  ],
  courses: [
    { id: 1, name: "B.Tech", department: "CSE", duration: "4 Years" },
    { id: 2, name: "B.Tech", department: "ECE", duration: "4 Years" }
  ],
  departments: [
    { id: 1, name: "CSE", head: "Dr. S. Kumar" },
    { id: 2, name: "ECE", head: "Prof. R. Devi" },
    { id: 3, name: "IT", head: "Dr. A. Rao" }
  ],
  attendance: [],
  timetable: [
    { id: 1, day: "Monday", time: "09:00 AM", course: "Programming", faculty: "Dr. S. Kumar", room: "Room 101" },
    { id: 2, day: "Tuesday", time: "10:00 AM", course: "Electronics", faculty: "Prof. R. Devi", room: "Room 202" }
  ],
  notices: [
    { id: 1, title: "Welcome to CollegePro", date: new Date().toISOString().slice(0, 10) },
    { id: 2, title: "Remember to check your timetable", date: new Date().toISOString().slice(0, 10) }
  ]
};

const fields = {
  students: [
    { key: "name", label: "Full Name", required: true },
    { key: "email", label: "Email", type: "email" },
    { key: "phone", label: "Phone" },
    { key: "department", label: "Department" },
    { key: "course", label: "Course" },
    { key: "year", label: "Year", options: ["1st Year", "2nd Year", "3rd Year", "4th Year"] }
  ],
  faculty: [
    { key: "name", label: "Faculty Name", required: true },
    { key: "email", label: "Email", type: "email" },
    { key: "phone", label: "Phone" },
    { key: "department", label: "Department" },
    { key: "subject", label: "Subject" }
  ],
  courses: [
    { key: "name", label: "Course Name", required: true },
    { key: "department", label: "Department" },
    { key: "duration", label: "Duration", options: ["1 Year", "2 Years", "3 Years", "4 Years"] }
  ],
  departments: [
    { key: "name", label: "Department Name", required: true },
    { key: "head", label: "Department Head" }
  ],
  timetable: [
    { key: "day", label: "Day", options: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"] },
    { key: "time", label: "Class Time", required: true },
    { key: "course", label: "Subject", required: true },
    { key: "faculty", label: "Faculty Name" },
    { key: "room", label: "Room" }
  ]
};

function cloneData(value) {
  return JSON.parse(JSON.stringify(value));
}

function loadDatabase() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) return cloneData(initialData);

    const parsed = JSON.parse(saved);
    const result = cloneData(initialData);

    Object.keys(result).forEach(key => {
      if (Array.isArray(parsed[key])) result[key] = parsed[key];
    });

    return result;
  } catch (error) {
    console.error("Could not load saved data:", error);
    return cloneData(initialData);
  }
}

let db = loadDatabase();
let editingRecord = null;

function saveDatabase() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
    return true;
  } catch (error) {
    alert("Could not save data. Check your browser storage settings.");
    console.error(error);
    return false;
  }
}

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[char]);
}

function nextId(type) {
  if (!db[type].length) return 1;
  return Math.max(...db[type].map(item => Number(item.id) || 0)) + 1;
}

function makeTable(headers, rows) {
  return `
    <div class="table-responsive">
      <table>
        <thead>
          <tr>${headers.map(h => `<th>${escapeHTML(h)}</th>`).join("")}</tr>
        </thead>
        <tbody>
          ${rows.length
            ? rows.join("")
            : `<tr><td colspan="${headers.length}">No records found.</td></tr>`}
        </tbody>
      </table>
    </div>`;
}

function actions(type, id) {
  return `
    <button class="edit-btn" type="button"
      data-edit="${type}" data-id="${id}">Edit</button>
    <button class="delete-btn" type="button"
      data-delete="${type}" data-id="${id}">Delete</button>`;
}

/* Dashboard */

function renderDashboard() {
  $("totalStudents").textContent = db.students.length;
  $("totalFaculty").textContent = db.faculty.length;
  $("totalCourses").textContent = db.courses.length;
  $("totalDepartments").textContent = db.departments.length;

  $("recentStudents").innerHTML = makeTable(
    ["Name", "Department", "Course"],
    db.students.slice(-5).reverse().map(s => `
      <tr>
        <td>${escapeHTML(s.name)}</td>
        <td>${escapeHTML(s.department)}</td>
        <td>${escapeHTML(s.course)}</td>
      </tr>`)
  );

  $("noticesList").innerHTML = db.notices.map(notice => `
    <div class="notice-item">
      <strong>${escapeHTML(notice.title)}</strong>
      <small>${escapeHTML(notice.date)}</small>
    </div>`).join("") || "<p>No announcements yet.</p>";
}

/* Students */

function renderStudents() {
  const query = $("studentSearch").value.trim().toLowerCase();

  const records = db.students.filter(student =>
    Object.values(student).some(value =>
      String(value).toLowerCase().includes(query)
    )
  );

  $("studentsTable").innerHTML = makeTable(
    ["ID", "Name", "Email", "Phone", "Department", "Course", "Year", "Actions"],
    records.map(s => `
      <tr>
        <td>${s.id}</td>
        <td>${escapeHTML(s.name)}</td>
        <td>${escapeHTML(s.email)}</td>
        <td>${escapeHTML(s.phone)}</td>
        <td>${escapeHTML(s.department)}</td>
        <td>${escapeHTML(s.course)}</td>
        <td>${escapeHTML(s.year)}</td>
        <td>${actions("students", s.id)}</td>
      </tr>`)
  );
}

/* Faculty */

function renderFaculty() {
  $("facultyTable").innerHTML = makeTable(
    ["ID", "Name", "Email", "Phone", "Department", "Subject", "Actions"],
    db.faculty.map(f => `
      <tr>
        <td>${f.id}</td>
        <td>${escapeHTML(f.name)}</td>
        <td>${escapeHTML(f.email)}</td>
        <td>${escapeHTML(f.phone)}</td>
        <td>${escapeHTML(f.department)}</td>
        <td>${escapeHTML(f.subject)}</td>
        <td>${actions("faculty", f.id)}</td>
      </tr>`)
  );
}

/* Courses */

function renderCourses() {
  $("coursesTable").innerHTML = makeTable(
    ["ID", "Course", "Department", "Duration", "Actions"],
    db.courses.map(c => `
      <tr>
        <td>${c.id}</td>
        <td>${escapeHTML(c.name)}</td>
        <td>${escapeHTML(c.department)}</td>
        <td>${escapeHTML(c.duration)}</td>
        <td>${actions("courses", c.id)}</td>
      </tr>`)
  );
}

/* Departments */

function renderDepartments() {
  $("departmentsTable").innerHTML = makeTable(
    ["ID", "Department", "Department Head", "Actions"],
    db.departments.map(d => `
      <tr>
        <td>${d.id}</td>
        <td>${escapeHTML(d.name)}</td>
        <td>${escapeHTML(d.head)}</td>
        <td>${actions("departments", d.id)}</td>
      </tr>`)
  );
}

/* Attendance */

function renderAttendance() {
  const date = $("attendanceDate").value;
  const records = db.attendance.filter(a => a.date === date);

  $("attendanceTable").innerHTML = makeTable(
    ["Student ID", "Student", "Department", "Attendance"],
    db.students.map(student => {
      const record = records.find(a => a.studentId === student.id);
      const status = record?.status || "";

      return `
        <tr>
          <td>${student.id}</td>
          <td>${escapeHTML(student.name)}</td>
          <td>${escapeHTML(student.department)}</td>
          <td>
            <select class="attendance-status" data-student="${student.id}"
              aria-label="Attendance for ${escapeHTML(student.name)}">
              <option value="" ${status === "" ? "selected" : ""}>Select status</option>
              <option value="Present" ${status === "Present" ? "selected" : ""}>Present</option>
              <option value="Absent" ${status === "Absent" ? "selected" : ""}>Absent</option>
              <option value="Late" ${status === "Late" ? "selected" : ""}>Late</option>
            </select>
          </td>
        </tr>`;
    })
  );
}

function saveAttendance() {
  const date = $("attendanceDate").value;

  if (!date) {
    alert("Please select an attendance date.");
    return;
  }

  const selects = document.querySelectorAll(".attendance-status");

  selects.forEach(select => {
    const studentId = Number(select.dataset.student);

    db.attendance = db.attendance.filter(record =>
      !(record.studentId === studentId && record.date === date)
    );

    if (select.value) {
      db.attendance.push({
        id: nextId("attendance"),
        studentId,
        date,
        status: select.value
      });
    }
  });

  if (saveDatabase()) {
    renderAll();
    alert("Attendance saved successfully!");
  }
}

/* Timetable */

function renderTimetable() {
  $("timetableTable").innerHTML = makeTable(
    ["ID", "Day", "Time", "Subject", "Faculty", "Room", "Actions"],
    db.timetable.map(t => `
      <tr>
        <td>${t.id}</td>
        <td>${escapeHTML(t.day)}</td>
        <td>${escapeHTML(t.time)}</td>
        <td>${escapeHTML(t.course)}</td>
        <td>${escapeHTML(t.faculty)}</td>
        <td>${escapeHTML(t.room)}</td>
        <td>${actions("timetable", t.id)}</td>
      </tr>`)
  );
}

/* Reports */

function renderReports() {
  const attendance = db.attendance;
  const present = attendance.filter(a => a.status === "Present").length;
  const absent = attendance.filter(a => a.status === "Absent").length;
  const late = attendance.filter(a => a.status === "Late").length;
  const total = attendance.length;
  const rate = total ? ((present / total) * 100).toFixed(1) + "%" : "N/A";

  $("reportsTable").innerHTML = makeTable(
    ["Report", "Value"],
    [
      `<tr><td>Total Students</td><td>${db.students.length}</td></tr>`,
      `<tr><td>Total Faculty</td><td>${db.faculty.length}</td></tr>`,
      `<tr><td>Total Courses</td><td>${db.courses.length}</td></tr>`,
      `<tr><td>Total Departments</td><td>${db.departments.length}</td></tr>`,
      `<tr><td>Total Attendance Records</td><td>${total}</td></tr>`,
      `<tr><td>Present Records</td><td>${present}</td></tr>`,
      `<tr><td>Absent Records</td><td>${absent}</td></tr>`,
      `<tr><td>Late Records</td><td>${late}</td></tr>`,
      `<tr><td>Attendance Rate (of marked records)</td><td>${rate}</td></tr>`
    ]
  );
}

function renderAll() {
  renderDashboard();
  renderStudents();
  renderFaculty();
  renderCourses();
  renderDepartments();
  renderAttendance();
  renderTimetable();
  renderReports();
}

/* Navigation */

function showPage(page) {
  const section = $(page);
  if (!section || !section.classList.contains("page")) return;

  document.querySelectorAll(".page").forEach(item => {
    item.classList.toggle("active", item.id === page);
  });

  document.querySelectorAll(".nav-link").forEach(button => {
    button.classList.toggle("active", button.dataset.page === page);
  });

  $("pageTitle").textContent =
    page.charAt(0).toUpperCase() + page.slice(1);

  $("sidebar").classList.remove("open");
  renderAll();
}

/* Add and edit forms */

function createFormFields(type, record = {}) {
  const definitions = fields[type];
  if (!definitions) return "";

  return definitions.map(field => {
    const id = "field-" + field.key;
    const value = record[field.key] ?? "";

    let control;

    if (field.options) {
      const options = [...field.options];

      if (value && !options.includes(value)) options.unshift(value);

      control = `
        <select id="${id}" name="${field.key}" ${field.required ? "required" : ""}>
          <option value="">Select ${escapeHTML(field.label)}</option>
          ${options.map(option => `
            <option value="${escapeHTML(option)}"
              ${option === value ? "selected" : ""}>
              ${escapeHTML(option)}
            </option>`).join("")}
        </select>`;
    } else {
      control = `
        <input id="${id}" name="${field.key}"
          type="${field.type || "text"}"
          value="${escapeHTML(value)}"
          placeholder="Enter ${escapeHTML(field.label.toLowerCase())}"
          ${field.required ? "required" : ""}>`;
    }

    return `
      <div class="form-field">
        <label for="${id}">${escapeHTML(field.label)}</label>
        ${control}
      </div>`;
  }).join("");
}

function openForm(type, id = null) {
  if (!fields[type]) return;

  const record = id === null
    ? {}
    : db[type].find(item => item.id === Number(id));

  if (id !== null && !record) {
    alert("Record not found.");
    return;
  }

  editingRecord = { type, id: id === null ? null : Number(id) };

  $("formTitle").textContent =
    `${id === null ? "Add" : "Edit"} ${type.slice(0, -1)}`;

  $("formFields").innerHTML = createFormFields(type, record || {});
  $("recordModal").classList.remove("hidden");

  const firstInput = $("formFields").querySelector("input, select");
  if (firstInput) firstInput.focus();
}

function closeForm() {
  $("recordModal").classList.add("hidden");
  $("recordForm").reset();
  $("formFields").innerHTML = "";
  editingRecord = null;
}

function saveRecord(event) {
  event.preventDefault();

  if (!editingRecord) return;

  const { type, id } = editingRecord;
  const formData = new FormData(event.currentTarget);
  const record = {};

  fields[type].forEach(field => {
    record[field.key] = String(formData.get(field.key) || "").trim();
  });

  if (fields[type].some(field =>
    field.required && !record[field.key]
  )) {
    alert("Please fill in all required fields.");
    return;
  }

  if (type === "departments") {
    const duplicate = db.departments.some(d =>
      d.name.toLowerCase() === record.name.toLowerCase() && d.id !== id
    );

    if (duplicate) {
      alert("That department already exists.");
      return;
    }
  }

  if (id !== null) {
    const index = db[type].findIndex(item => item.id === id);
    if (index === -1) return;

    const oldDepartment = type === "departments"
      ? db[type][index].name
      : null;

    db[type][index] = { ...db[type][index], ...record };

    if (type === "departments" && oldDepartment !== record.name) {
      ["students", "faculty", "courses"].forEach(list => {
        db[list].forEach(item => {
          if (item.department === oldDepartment) {
            item.department = record.name;
          }
        });
      });
    }
  } else {
    db[type].push({ id: nextId(type), ...record });
  }

  if (saveDatabase()) {
    closeForm();
    renderAll();
  }
}

/* Delete records */

function deleteRecord(type, id) {
  const numericId = Number(id);
  const record = db[type]?.find(item => item.id === numericId);
  if (!record) return;

  if (!confirm("Delete this record? This action cannot be undone.")) return;

  db[type] = db[type].filter(item => item.id !== numericId);

  if (type === "students") {
    db.attendance = db.attendance.filter(a => a.studentId !== numericId);
  }

  if (type === "departments") {
    // Keep existing linked records intact; they may need reassignment.
  }

  if (saveDatabase()) renderAll();
}

/* CSV export */

function exportCSV(type) {
  const records = type === "attendance-export" ? db.attendance : db[type];

  if (!Array.isArray(records) || records.length === 0) {
    alert("There are no records to export.");
    return;
  }

  const columns = [...new Set(records.flatMap(record => Object.keys(record)))];

  const csvCell = value =>
    '"' + String(value ?? "").replace(/"/g, '""') + '"';

  const csv = [
    columns.map(csvCell).join(","),
    ...records.map(record =>
      columns.map(column => csvCell(record[column])).join(",")
    )
  ].join("\r\n");

  const blob = new Blob(["\uFEFF" + csv], {
    type: "text/csv;charset=utf-8;"
  });

  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `${type.replace("-export", "")}-report.csv`;

  document.body.appendChild(link);
  link.click();
  link.remove();

  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/* Login and logout */

function showApp() {
  $("loginPage").classList.add("hidden");
  $("app").classList.remove("hidden");
  renderAll();
}

function showLogin() {
  $("app").classList.add("hidden");
  $("loginPage").classList.remove("hidden");
}

function handleLogin(event) {
  event.preventDefault();

  const email = $("loginEmail").value.trim().toLowerCase();
  const password = $("loginPassword").value;
  const error = $("loginError");

  if (email === "admin@collegepro.com" && password === "college123") {
    sessionStorage.setItem(LOGIN_KEY, "true");
    error.textContent = "";
    showApp();
  } else {
    error.textContent = "Incorrect email or password. Please try again.";
  }
}

function logout() {
  sessionStorage.removeItem(LOGIN_KEY);
  showLogin();
  $("loginPassword").value = "";
  $("loginError").textContent = "";
}

/* Theme */

function toggleTheme() {
  document.body.classList.toggle("dark-mode");

  const theme = document.body.classList.contains("dark-mode")
    ? "dark"
    : "light";

  localStorage.setItem(THEME_KEY, theme);
  $("themeToggle").textContent = theme === "dark" ? "☀" : "☾";
}

/* Start application */

function initializeApp() {
  if (localStorage.getItem(THEME_KEY) === "dark") {
    document.body.classList.add("dark-mode");
  }

  $("themeToggle").textContent =
    document.body.classList.contains("dark-mode") ? "☀" : "☾";

  $("attendanceDate").value = new Date().toISOString().slice(0, 10);

  $("loginForm").addEventListener("submit", handleLogin);
  $("recordForm").addEventListener("submit", saveRecord);
  $("studentSearch").addEventListener("input", renderStudents);
  $("attendanceDate").addEventListener("change", renderAttendance);
  $("saveAttendance").addEventListener("click", saveAttendance);
  $("closeModal").addEventListener("click", closeForm);
  $("cancelModal").addEventListener("click", closeForm);
  $("logoutButton").addEventListener("click", logout);

  $("themeToggle").addEventListener("click", toggleTheme);

  $("menuToggle").addEventListener("click", () => {
    $("sidebar").classList.toggle("open");
  });

  $("exportAttendance").addEventListener("click", () => {
    exportCSV("attendance-export");
  });

  document.addEventListener("click", event => {
    const pageButton = event.target.closest("[data-page]");
    if (pageButton) showPage(pageButton.dataset.page);

    const addButton = event.target.closest("[data-add]");
    if (addButton) openForm(addButton.dataset.add);

    const editButton = event.target.closest("[data-edit]");
    if (editButton) {
      openForm(editButton.dataset.edit, editButton.dataset.id);
    }

    const deleteButton = event.target.closest("[data-delete]");
    if (deleteButton) {
      deleteRecord(deleteButton.dataset.delete, deleteButton.dataset.id);
    }

    const exportButton = event.target.closest("[data-export]");
    if (exportButton) exportCSV(exportButton.dataset.export);

    if (event.target === $("recordModal")) closeForm();
  });

  if (sessionStorage.getItem(LOGIN_KEY) === "true") {
    showApp();
  } else {
    showLogin();
  }

  renderAll();
}

document.addEventListener("DOMContentLoaded", initializeApp);
